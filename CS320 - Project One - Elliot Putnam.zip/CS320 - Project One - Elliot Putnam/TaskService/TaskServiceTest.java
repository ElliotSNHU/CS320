import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testTaskAddition() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");
        taskService.addTask(task);
        assertEquals(1, taskService.getTasks().size());
    }

    @Test
    public void testDuplicateTaskAddition() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");
        taskService.addTask(task);

        // Attempting to add a task with the same ID should throw an exception
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(new Task("12345", "NewTaskName", "NewTaskDescription")));
    }

    @Test
    public void testTaskDeletion() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");
        taskService.addTask(task);
        taskService.deleteTask("12345");
        assertEquals(0, taskService.getTasks().size());
    }

    @Test
    public void testNonExistentTaskDeletion() {
        TaskService taskService = new TaskService();

        // Attempting to delete a task that doesn't exist should throw an exception
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("12345"));
    }

    @Test
    public void testTaskUpdate() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");
        taskService.addTask(task);
        taskService.updateTask("12345", "NewTaskName", "NewTaskDescription");

        Task updatedTask = taskService.getTasks().get(0);
        assertEquals("NewTaskName", updatedTask.getName());
        assertEquals("NewTaskDescription", updatedTask.getDescription());
    }

    @Test
    public void testTaskUpdateNonExistentID() {
        TaskService taskService = new TaskService();

        // Attempting to update a task that doesn't exist should throw an exception
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("12345", "NewTaskName", "NewTaskDescription"));
    }
}
