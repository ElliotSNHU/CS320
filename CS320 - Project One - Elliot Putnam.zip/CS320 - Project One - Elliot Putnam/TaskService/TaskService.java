import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TaskService {
    private final List<Task> tasks;

    public TaskService() {
        this.tasks = new ArrayList<>();
    }

    public void addTask(Task task) {
        // Check for duplicate task ID before adding
        for (Task t : tasks) {
            if (t.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID must be unique");
            }
        }
        tasks.add(task);
    }

    public void deleteTask(String taskId) {
        Iterator<Task> iterator = tasks.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (task.getTaskId().equals(taskId)) {
                iterator.remove();
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }

    public void updateTask(String taskId, String newName, String newDescription) {
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                if (newName != null && newName.length() <= 20) {
                    task.setName(newName);
                }
                if (newDescription != null && newDescription.length() <= 50) {
                    task.setDescription(newDescription);
                }
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }
    
    public List<Task> getTasks()
    {
    	return tasks;
    }
}
