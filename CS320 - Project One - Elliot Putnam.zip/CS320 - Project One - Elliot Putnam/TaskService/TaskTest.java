import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("1234567890", "TaskName", "TaskDescription");
        assertEquals("1234567890", task.getTaskId());
        assertEquals("TaskName", task.getName());
        assertEquals("TaskDescription", task.getDescription());
    }

    @Test
    public void testSetName() {
        Task task = new Task("Task1", "TaskName", "TaskDescription");
        task.setName("NewTaskName");
        assertEquals("NewTaskName", task.getName());
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("Task1", "TaskName", "TaskDescription");
        task.setDescription("NewTaskDescription");
        assertEquals("NewTaskDescription", task.getDescription());
    }
    
    
}
