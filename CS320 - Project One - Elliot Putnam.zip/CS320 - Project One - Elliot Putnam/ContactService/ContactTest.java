import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testContactCreation() {
    	// Creates contact object to test
        Contact contact = new Contact("12345", "John", "Doe", "9999999999", "123 Main St");

        // Assertions check if the contact is created correctly
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("9999999999", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }
}
