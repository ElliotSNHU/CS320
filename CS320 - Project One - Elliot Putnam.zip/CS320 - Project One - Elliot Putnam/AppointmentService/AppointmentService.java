import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    private List<Appointment> appointments;

    public AppointmentService() {
        appointments = new ArrayList<>();
    }

    // Adds new appointment object
    public void addAppointment(Appointment appointment) {
        for (Appointment existingAppointment : appointments) {
            if (existingAppointment.getAppointmentID().equals(appointment.getAppointmentID())) {
                throw new IllegalArgumentException("Appointment ID already exists");
            }
        }
        appointments.add(appointment);
    }

    // Deletes appointment object
    public void deleteAppointment(String appointmentID) {
        appointments.removeIf(appointment -> appointment.getAppointmentID().equals(appointmentID));
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }
}
