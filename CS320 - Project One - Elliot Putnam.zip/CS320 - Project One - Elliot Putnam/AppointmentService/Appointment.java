import java.util.Date;

public class Appointment {
	// required fields
    private String appointmentID;
    private Date appointmentDate;
    private String description;

    // Constructor for Appointment
    public Appointment(String appointmentID, Date appointmentDate, String description) {
        if (isValidAppointmentID(appointmentID) && isValidAppointmentDate(appointmentDate) && isValidDescription(description)) {
            this.appointmentID = appointmentID;
            this.appointmentDate = appointmentDate;
            this.description = description;
        } else {
            throw new IllegalArgumentException("Invalid input parameters");
        }
    }

    // Getter Methods
    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    // Booleans to check validation
    private boolean isValidAppointmentID(String appointmentID) {
        return appointmentID != null && !appointmentID.isEmpty() && appointmentID.length() <= 10;
    }

    private boolean isValidAppointmentDate(Date appointmentDate) {
        return appointmentDate != null && appointmentDate.after(new Date());
    }

    private boolean isValidDescription(String description) {
        return description != null && description.length() <= 50;
    }
}
