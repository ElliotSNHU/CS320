import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        // Test valid task creation
        Task task = new Task("8675309", "Jenny", "who can I turn to?");
        Assertions.assertEquals("8675309", task.getTaskId());
        Assertions.assertEquals("Jenny", task.getName());
        Assertions.assertEquals("who can I turn to?", task.getDescription());
    }

    @Test
    public void testTaskIdValidation() {
        // Test for invalid task ID (length > 10)
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> new Task("99999999999", "HoneyBun", "It's under 100 BILLION!.")
        );

        // Test for null task ID
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> new Task(null, "No ID Task", "IT'S NOT IN THE SYSTEM!")
        );
    }

    @Test
    public void testNameValidation() {
        // Test for invalid name (length > 20)
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> new Task("1", "Super Long Task Name Surely Wont Pass!", "No shot.")
        );

        // Test for null name
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> new Task("2", null, "A null task name!")
        );
    }

    @Test
    public void testDescriptionValidation() {
        // Test for invalid description (length > 50)
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> new Task("3", "Bel-air", "This is a story all about how my description went long and I don't know how, and I'd like to take a minute just sit right there." )
        );

        // Test for null description
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> new Task("4", "ReadDesc", null)
        );
    }

    @Test
    public void testSetName() {
    	// Test setting a valid name
        Task task = new Task("5", "Valid", "Just a Valid Test");
        task.setName("StillValid");
        Assertions.assertEquals("StillValid", task.getName());

        // Test setting an invalid name (length > 20)
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> task.setName("Time to test a new name that may not be valid.")
        );

        // Test setting a null name
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> task.setName(null)
        );
    }

    @Test
    public void testSetDescription() {
        // Test setting a valid description
        Task task = new Task("6", "SIXIES", "Old Description");
        task.setDescription("New Description");
        Assertions.assertEquals("New Description", task.getDescription());

        // Test setting an invalid description (length > 50)
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> task.setDescription("A new description, but old in the test. Wizened by years of iteration, it has yet to fail us.")
        );

        // Test setting a null description
        Assertions.assertThrows(
            IllegalArgumentException.class,
            () -> task.setDescription(null)
        );
    }
}
      
