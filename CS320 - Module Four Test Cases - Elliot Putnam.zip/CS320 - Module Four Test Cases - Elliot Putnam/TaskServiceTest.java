import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    @Test
    public void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1", "Task 1", "Description 1");
        
        taskService.addTask(task);
        
        Task retrievedTask = taskService.getTaskById("1");
        Assertions.assertNotNull(retrievedTask);
        Assertions.assertEquals("1", retrievedTask.getTaskId());
        Assertions.assertEquals("Task 1", retrievedTask.getName());
        Assertions.assertEquals("Description 1", retrievedTask.getDescription());
    }
}
