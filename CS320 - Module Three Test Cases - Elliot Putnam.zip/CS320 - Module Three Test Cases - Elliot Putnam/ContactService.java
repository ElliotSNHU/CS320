import java.util.HashMap;
import java.util.Map;

public class ContactService {
	// Map to store contacts and IDs
    private final Map<String, Contact> contacts;

    // Constructor to initialize ContactServices
    public ContactService() {
        this.contacts = new HashMap<>();
    }

    // Adds contact to service
    public void addContact(Contact contact) {
        contacts.put(contact.getContactId(), contact);
    }

    // Deletes contact from service
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    // Updates contact field, excluding contactId
    public void updateContactField(String contactId, String field, String value) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            switch (field.toLowerCase()) {
                case "firstname":
                    contact.firstName = value;
                    break;
                case "lastname":
                    contact.lastName = value;
                    break;
                case "number":
                    contact.phone = value;
                    break;
                case "address":
                    contact.address = value;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid field name");
            }
        }
    }
    
    // Gets contact by ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}