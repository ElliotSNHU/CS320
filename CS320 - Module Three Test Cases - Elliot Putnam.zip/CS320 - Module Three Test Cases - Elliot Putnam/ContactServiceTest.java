import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
    	// Creates contactService object to test
        ContactService contactService = new ContactService();
        
        // Creates new contact and adds it to service
        Contact contact = new Contact("12345", "John", "Doe", "9999999999", "123 Main St");
        contactService.addContact(contact);

        // Assertion to check if contact was added successfully.
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testDeleteContact() {
    	// Creates contactService object to test
        ContactService contactService = new ContactService();
        
        // Creates contact to add
        Contact contact = new Contact("12345", "John", "Doe", "9999999999", "123 Main St");
        contactService.addContact(contact);
        // Deletes the same contact
        contactService.deleteContact("12345");

        // Assertion to check if contact was deleted
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testUpdateContactField() {
    	// Creates new contactService to test
        ContactService contactService = new ContactService();
        
        // Creates contact to add
        Contact contact = new Contact("12345", "John", "Doe", "9999999999", "123 Main St");
        contactService.addContact(contact);
        
        // Updates contact with new data
        contactService.updateContactField("12345", "firstname", "Jane");

        // Assertion to check if contact was successfully updated
        assertEquals("Jane", contactService.getContact("12345").getFirstName());
    }
}