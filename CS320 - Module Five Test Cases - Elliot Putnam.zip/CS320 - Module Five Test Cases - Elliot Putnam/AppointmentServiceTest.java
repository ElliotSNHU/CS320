import org.junit.Before;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @Before
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        // Creating a future date
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); // Adding one day
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("Appt1", futureDate, "Description");
        appointmentService.addAppointment(appointment);
        assertEquals(1, appointmentService.getAppointments().size());
    }

    @Test
    public void testAddDuplicateAppointment() {
        // Creating future dates
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); // Adding one day
        Date futureDate = calendar.getTime();

        Appointment appointment1 = new Appointment("Appt1", futureDate, "Description");
        Appointment appointment2 = new Appointment("Appt1", futureDate, "Description");

        appointmentService.addAppointment(appointment1);
        try {
            appointmentService.addAppointment(appointment2);
            fail("Expected an IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment ID already exists", e.getMessage());
        }
    }

    @Test
    public void testDeleteAppointment() {
        // Creating a future date
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); // Adding one day
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("Appt1", futureDate, "Description");
        appointmentService.addAppointment(appointment);

        appointmentService.deleteAppointment("Appt1");
        assertEquals(0, appointmentService.getAppointments().size());
    }

    // Additional tests for appointment service functionalities
}
