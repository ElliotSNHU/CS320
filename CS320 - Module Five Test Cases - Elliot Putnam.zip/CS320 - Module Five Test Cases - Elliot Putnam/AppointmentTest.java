import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date currentDate = new Date();
        Date futureDate = new Date(currentDate.getTime() + 86400000); // Adding 1 day in milliseconds
        Appointment appointment = new Appointment("Appt1", futureDate, "Description");
        assertEquals("Appt1", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Description", appointment.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAppointmentCreation() {
        Date pastDate = new Date(10000); // A date in the past
        new Appointment("Appt1", pastDate, "This description is too long and should fail");
    }
}
